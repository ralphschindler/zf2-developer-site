<?php
namespace Zend\Di\Exception;

use Zend\Di\Exception;

class InvalidPositionException 
    extends InvalidArgumentException 
    implements Exception
{
}
