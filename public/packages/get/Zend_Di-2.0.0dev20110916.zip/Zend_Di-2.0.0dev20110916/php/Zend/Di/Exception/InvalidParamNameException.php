<?php
namespace Zend\Di\Exception;

use Zend\Di\Exception;

class InvalidParamNameException 
    extends InvalidArgumentException 
    implements Exception
{
}
