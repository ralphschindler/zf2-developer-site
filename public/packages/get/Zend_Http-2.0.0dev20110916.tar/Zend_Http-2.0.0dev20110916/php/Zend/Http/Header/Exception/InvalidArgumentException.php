<?php

namespace Zend\Http\Header\Exception;

use Zend\Http\Header\Exception;

class InvalidArgumentException 
    extends \InvalidArgumentException 
    implements Exception
{
}
