<?php

namespace Zend\Stdlib;

interface Exception
{
}
