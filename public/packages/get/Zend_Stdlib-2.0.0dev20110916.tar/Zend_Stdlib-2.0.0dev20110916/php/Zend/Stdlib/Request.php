<?php

namespace Zend\Stdlib;

class Request extends Message implements RequestDescription
{
    // generic request implementation
}
