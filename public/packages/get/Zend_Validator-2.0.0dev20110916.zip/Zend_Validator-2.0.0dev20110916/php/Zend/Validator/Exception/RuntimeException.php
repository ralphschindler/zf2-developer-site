<?php

namespace Zend\Validator\Exception;

class RuntimeException
    extends \RuntimeException
    implements \Zend\Validator\Exception
{
}
